<?php

$wynik = '<?xml version="1.0" encoding="utf-8"?>';
$wynik .= '<nagrody>';

$plik = file('nobel.txt');
foreach ($plik as $linia) {
    $e = explode('|', trim($linia)); 
    $wynik .= "
    
        <nagroda>
            <rok>$e[0]</rok>
            <fizyka>$e[1]</fizyka>
            <chemia>$e[2]</chemia>
            <medycyna>$e[3]</medycyna>
            <literatura>$e[4]</literatura>
            <pokojowa>$e[5]</pokojowa>
        </nagroda>
        
    ";
}

$wynik .= '</nagrody>';

file_put_contents('nobel.xml', $wynik);
?>