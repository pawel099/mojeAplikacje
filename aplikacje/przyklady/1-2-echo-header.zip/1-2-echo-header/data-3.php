<?php

header('Content-type: application/xml; charset="utf-8"');

echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<data>';
echo '<dzien>' . date('j') . '</dzien>';
echo '<miesiac>' . date('n') . '</miesiac>';
echo '<rok>' . date('Y') . '</rok>';
echo '</data>';

?>