<?php

header('Content-type: application/xml; charset="utf-8"');

?><?xml version="1.0" encoding="utf-8"?>

<data>
    <dzien>13</dzien>
    <miesiac>maj</miesiac>
    <rok>2004</rok>
</data>
