<?php

header('Content-type: application/xml; charset="utf-8"');

echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<data>';
echo '<dzien>13</dzien>';
echo '<miesiac>maj</miesiac>';
echo '<rok>2004</rok>';
echo '</data>';

?>