<?php

$owoce = file('owoce.txt');

$wynik = '<?xml version="1.0" encoding="utf-8"?>';
$wynik .= '<owoce>';

foreach ($owoce as $owoc) {
    $wynik .= '<owoc>';
    $wynik .= trim($owoc);
    $wynik .= '</owoc>';    
}

$wynik .= '</owoce>';

file_put_contents('owoce.xml', $wynik);

?>