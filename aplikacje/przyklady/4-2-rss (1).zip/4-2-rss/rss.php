<?php

header('Content-type: application/rss+xml; charset="utf-8"');

require_once 'Smarty.class.php';
require_once 'include/vh-array.inc.php';

$menu = string2VArray(file_get_contents('dane/menu.txt'));
$rss = string2VArray(file_get_contents('dane/rss.txt'));

$s = new Smarty;
$s->assign('menu', $menu[2]);
$s->assign('rss', $rss[2]);

$s->display('rss.tpl');

?>