<?php

function string2HArray($AStr, $ASeparator = '|')
{
    $tmpstr = trim($AStr);
    if ($tmpstr == '') {
        return false;
    } else {

        $linie  = explode("\n", trim($tmpstr));
        $liniec = count($linie);

        $t = array();

        for ($i = 0; $i < $liniec; $i++) {
            $linia   = explode($ASeparator, trim($linie[$i]));
            $t[] = $linia;
        }

        return array($liniec, $t);
    }
}

function string2VArray($AStr, $ASeparator = '|')
{
    $tmpstr = trim($AStr);
    if ($tmpstr == '') {
        return false;
    } else {

        $linie  = explode("\n", trim($tmpstr));
        $liniec = count($linie);

        $linia     = explode($ASeparator, trim($linie[0]));
        $liczbapol = count($linia);

        $t    = array();
        for ($j = 0; $j < $liczbapol; $j++) {
            $t[$j]   = array();
            $t[$j][] = $linia[$j];
        }

        for ($i = 1; $i < $liniec; $i++) {
            $linia = explode($ASeparator, trim($linie[$i]));

            if (count($linia) !== $liczbapol) {
                return false;
            }

            for ($j = 0; $j < $liczbapol; $j++) {
                $t[$j][] = $linia[$j];
            }
        }

        return array($liniec, $liczbapol, $t);
    }
}

function vArray2String($AArray, $ARows, $AColumns, $ASeparator)
{
    $result = '';
    for ($i = 0; $i < $ARows; $i++) {
        $tmp = '';
        for ($j = 0; $j < $AColumns; $j++) {
            $tmp .= $AArray[$j][$i] . $ASeparator;
        }
        $tmp = trim($tmp, $ASeparator);
        $result .= $tmp . "\r\n";
    }
    return $result;
}

function hArray2String($AArray, $ARows, $ASeparator)
{
    $result = '';
    for ($i = 0; $i < $ARows; $i++) {
        $tmp = implode($ASeparator, $AArray[$i]);
        $result .= $tmp . "\r\n";
    }
    return $result;
}

?>
