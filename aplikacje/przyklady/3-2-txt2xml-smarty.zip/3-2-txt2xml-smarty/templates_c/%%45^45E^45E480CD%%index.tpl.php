<?php /* Smarty version 2.6.18, created on 2008-01-07 13:26:37
         compiled from index.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="utf-8"<?php echo '?>'; ?>

<mecze>
<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['mecze']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>

  <mecz>
    <kolejka><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][0]; ?>
</kolejka>
    <gospodarz><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][1]; ?>
</gospodarz>
    <przeciwnik><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][2]; ?>
</przeciwnik>    
    <wynik>    
        <gospodarz><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][3]; ?>
</gospodarz>
	<przeciwnik><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][4]; ?>
</przeciwnik>    
    </wynik>                
    <wynikDoPrzerwy>
        <gospodarz><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][5]; ?>
</gospodarz>
	<przeciwnik><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][6]; ?>
</przeciwnik>
    </wynikDoPrzerwy>	
    <data>
        <rok><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][7]; ?>
</rok>
	<miesiac><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][8]; ?>
</miesiac>
	<dzien><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][9]; ?>
</dzien>
        <godzina><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][10]; ?>
</godzina>    	
        <minuta><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][11]; ?>
</minuta>
    </data>	
    <sedziaGlowny>
        <imie><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][12]; ?>
</imie>
        <nazwisko><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][13]; ?>
</nazwisko>
	<miasto><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][14]; ?>
</miasto>
    </sedziaGlowny>
    <sedziowieLiniowi>
        <sedzia>
            <imie><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][15]; ?>
</imie>
	    <nazwisko><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][16]; ?>
</nazwisko>
	</sedzia>
        <sedzia>
            <imie><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][17]; ?>
</imie>
	    <nazwisko><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][18]; ?>
</nazwisko>
	</sedzia>
    </sedziowieLiniowi>
    <widownia><?php echo $this->_tpl_vars['mecze'][$this->_sections['i']['index']][19]; ?>
</widownia>	
  </mecz>
  
<?php endfor; endif; ?>
</mecze>