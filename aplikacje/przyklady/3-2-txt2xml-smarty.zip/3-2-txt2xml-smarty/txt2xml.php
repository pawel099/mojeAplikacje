<?php

require_once 'vh-array.inc.php';
require_once 'Smarty.class.php';

$p = file_get_contents('mecze.txt');
$k = string2HArray($p);

$s = new Smarty;
$s->assign('mecze', $k[1]);
$wynik = $s->fetch('index.tpl');

file_put_contents('mecze.xml', $wynik);

?>
