<?php

header('Content-type: application/xml; charset="utf-8"');

$owoce = array(
    'jabłko',
    'gruszka',
    'banan',
    'kiwi',
    'mango',
    'marakuja',
    'czarna porzeczka',
    'czerwona porzeczka',
    'śliwka',
    'jagoda',
    'malina',
    'truskawka',
    'jeżyna',
    'poziomka',
    'wiśnia',
    'czereśnia',
    'mirabelka',
    'pomarańcza',
    'mandarynka',
    'grejpfrut',
    'ananas',
    'orzech laskowy',
    'kokos',
    'orzech włoski',
    'orzech ziemny',
    'daktyl',
    'figa',
    'oliwka',
    'brzoskwinia',
    'morela'
);


echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<owoce>';

foreach ($owoce as $owoc) {
    echo '<owoc>';
    echo $owoc;
    echo '</owoc>';    
}

echo '</owoce>';

?>