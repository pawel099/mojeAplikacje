<?php /* Smarty version 2.6.18, created on 2008-01-03 08:52:02
         compiled from format1.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="utf-8"<?php echo '?>'; ?>

<turniejCzterechSkocznii>
<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['dane'][1]) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
    <zawody>
        <rok><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][0]; ?>
</rok>
        <miejsce>
            <numer><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][1]; ?>
</numer>
            <sportowiec>
                <imie><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][2]; ?>
</imie>
                <nazwisko><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][3]; ?>
</nazwisko>
                <kraj><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][4]; ?>
</kraj>
            </sportowiec>
        </miejsce>
        <miejsce>
            <numer><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][5]; ?>
</numer>
            <sportowiec>
                <imie><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][6]; ?>
</imie>
                <nazwisko><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][7]; ?>
</nazwisko>
                <kraj><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][8]; ?>
</kraj>
            </sportowiec>
        </miejsce>        
        <miejsce>
            <numer><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][9]; ?>
</numer>
            <sportowiec>
                <imie><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][10]; ?>
</imie>
                <nazwisko><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][11]; ?>
</nazwisko>
                <kraj><?php echo $this->_tpl_vars['dane'][1][$this->_sections['i']['index']][12]; ?>
</kraj>
            </sportowiec>
        </miejsce>                
    </zawody>
<?php endfor; endif; ?>
</turniejCzterechSkocznii>