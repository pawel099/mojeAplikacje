<?php

require_once 'Smarty.class.php';
require_once 'vh-array.inc.php';



$p = file_get_contents('tcs.txt');
$dane = string2HArray($p);


$s = new Smarty;
$s->assign('dane', $dane);
$wynik = $s->fetch('format1.tpl');

file_put_contents('tcs.xml', $wynik);

?>