<?php /* Smarty version 2.6.18, created on 2008-01-10 10:49:25
         compiled from atom.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="utf-8"<?php echo '?>'; ?>

<feed xmlns="http://www.w3.org/2005/Atom">
    <title type="text">Lorem ipsum</title>
    <subtitle type="html">Dolor &lt;em&gt;sit&lt;/em&gt; amet!</subtitle>
    <id>http://example.net/atom/</id>
    <link rel="self" type="application/atom+xml" href="http://example.net/atom/" />        
    <link rel="alternate" type="text/html" href="http://example.net/"/>    
    <updated>2008-01-02T10:15:00Z</updated>
    <author>
        <name>Jan Kowalski</name>
    </author>
    <rights>Copyright (c) 2003 Jan Kowalski</rights>    
    

    
    
<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['menu'][0]) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
    <entry>
        <title><?php echo $this->_tpl_vars['menu'][0][$this->_sections['i']['index']]; ?>
</title>
        <link href="http://example.net/index.php?id=<?php echo $this->_tpl_vars['menu'][2][$this->_sections['i']['index']]; ?>
" />
        <updated><?php echo $this->_tpl_vars['atom'][0][$this->_sections['i']['index']]; ?>
</updated>
        <summary><?php echo $this->_tpl_vars['atom'][1][$this->_sections['i']['index']]; ?>
</summary>
    </entry>    

<?php endfor; endif; ?>        
    
</feed>



