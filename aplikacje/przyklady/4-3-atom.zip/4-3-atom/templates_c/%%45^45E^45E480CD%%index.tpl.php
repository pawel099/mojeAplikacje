<?php /* Smarty version 2.6.18, created on 2008-01-10 10:49:23
         compiled from index.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">
  <head>
    <title>Lorem ipsum</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <link rel="alternate" type="application/atom+xml" href="atom.php" />    
  </head>
<body>

<p id="skiptocontent">
    <a href="#content">skip to content</a>
</p>

<h1 id="logo">Lorem ipsum</h1>


<ul id="menu">
<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['menu'][0]) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
    <li><a href="index.php?id=<?php echo $this->_tpl_vars['menu'][2][$this->_sections['i']['index']]; ?>
"><?php echo $this->_tpl_vars['menu'][0][$this->_sections['i']['index']]; ?>
</a></li>
<?php endfor; endif; ?>    
</ul>

<div id="content">
<?php if ($this->_tpl_vars['akcja'] == 1): ?>
    <p>Błąd!Podana strona nie istnieje!</p>
<?php else: ?>
    <?php echo $this->_tpl_vars['dane']; ?>

<?php endif; ?>

</div>


<div id="footer">
    &copy;2007 lorem ipsum
</div>

</body>
</html>