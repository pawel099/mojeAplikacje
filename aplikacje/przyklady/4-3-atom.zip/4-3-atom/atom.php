<?php

header('Content-type: application/atom+xml; charset="utf-8"');

require_once 'Smarty.class.php';
require_once 'include/vh-array.inc.php';

$s = new Smarty;

$menu = string2VArray(trim(file_get_contents('dane/menu.txt')));
$atom = string2VArray(trim(file_get_contents('dane/atom.txt')));
$s->assign('menu', $menu[2]);
$s->assign('atom', $atom[2]);

$s->display('atom.tpl');

?>