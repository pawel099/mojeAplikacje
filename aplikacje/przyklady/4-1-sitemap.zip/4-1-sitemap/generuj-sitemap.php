<?php

require_once 'Smarty.class.php';
require_once 'include/vh-array.inc.php';

$p = file_get_contents('dane/menu.txt');
$menu = string2VArray($p);

$s = new Smarty;
$s->assign('menu', $menu[2]);
$mapa = $s->fetch('sitemap.tpl');

file_put_contents('sitemap.xml', $mapa);

?>