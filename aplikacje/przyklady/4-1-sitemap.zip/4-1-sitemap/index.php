<?php

require_once 'Smarty.class.php';
require_once 'include/walidacja.inc.php';
require_once 'include/vh-array.inc.php';

$s = new Smarty;


/*
 * AKCJE
 *
 * 1 - B��D
 *
 *  2, 3, 4, 5 - wg pliku dane/menu.txt
 *
 * 2 - LOREM  
 * 3 - IPSUM
 * 4 - DOLOR
 * 5 - SIT AMET
 */
 
$menu = string2VArray(trim(file_get_contents('dane/menu.txt')));
$s->assign('menu', $menu[2]);
 
$akcja = 1;

if (empty($_GET)) {
    $_GET['id'] = '2';
}

if (isset($_GET['id']) && str_ievpifr($_GET['id'], 2, $menu[0] + 1)) {
    $akcja = $_GET['id'];
}        


if ($akcja == 1) {
    header('HTTP/1.x 404 Not Found');    
} else {
    $dane = file_get_contents('dane/' . $menu[2][1][$akcja - 2]);
    $s->assign('dane', $dane);
}

$s->assign('akcja', $akcja);
$s->display('index.tpl');

?>