<?php

header('Content-type: application/xml; charset="utf-8"');

echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<owoce>';

$owoce = file('owoce.txt');

foreach ($owoce as $owoc) {
    echo '<owoc>';
    echo trim($owoc);
    echo '</owoc>';    
}

echo '</owoce>';

?>