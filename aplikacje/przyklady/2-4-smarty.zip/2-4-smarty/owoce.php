<?php

header('Content-type: application/xml; charset="utf-8"');

require_once 'Smarty.class.php';

$plk = file('owoce.txt');
$s = new Smarty;
$s->assign('owoce', $plk);
$s->display('owoce.tpl');

?>