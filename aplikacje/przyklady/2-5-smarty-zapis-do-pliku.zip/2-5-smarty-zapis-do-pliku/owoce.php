<?php

require_once 'Smarty.class.php';

$plk = file('owoce.txt');
$s = new Smarty;
$s->assign('owoce', $plk);
$wynik = $s->fetch('owoce.tpl');

file_put_contents('owoce.xml', $wynik);

?>