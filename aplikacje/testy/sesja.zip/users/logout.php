<?php 

 require_once 'sesja.php';
  
   class wprogram  {
          
		  public function __construct() {
		  
		  $this->tokenC(); 
		  echo $this->user;
      
	  }  
   }

   
  new wyjscie();