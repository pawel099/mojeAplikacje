<?php require_once 'sesja.php'?>

<form action="users.php" method="Post">
uzytkownik <input type="text" name ="user"/></p>
hasło <input type="password" name ="haslo"/></p>
<input type="submit" name = "sends" value="wyslij">
</form>

