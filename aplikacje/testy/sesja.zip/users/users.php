<?php 
 
    require_once 'sesja.php';

	class program extends dane {
          
		  public function __construct() {
		  
		  $this->tokenA($_SESSION['sesja']);
		   
		       
		         echo $this->user;
		    
      
	   }  
   }


 new program() ;
 


