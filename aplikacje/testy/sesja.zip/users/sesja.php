<?php 

session_start();

$_SESSION['sesja'];


 interface szablon {
  
  function tokenA($users);
  function tokenB();
  function tokenC();
  
 }
 
 class dane implements szablon  {
 
 protected $settings;
 protected $sesja;
 
  
  protected $user;
 
   function tokenA($users) {
   
   $this->settings = // ustawienia cookies 
   $this->sesja = $users;
   
    
   
   
     if (isset($_SESSION['sesja'])) {
          $this->user = "sesja jest ustawiona";
		  
   
       }
 
   }
 
 
          function tokenB() {
		     
			// ustawienia sesji   
           
		   }
 
  function tokenC() {
  
   session_destroy();
     $this->user = "jestes obecnie wylogowany";
 
}
 
}


   


