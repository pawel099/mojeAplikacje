<?php 
session_start();

 if (isset($_SESSION['uzytkownik'])) {
require_once 'function/funkcje.php'; 
require_once 'includes/header.php'; 



function dodajFotki() {
   
            if (isset($_POST['przycisk'])) { 

   $dir=$_SERVER['DOCUMENT_ROOT'].'/strona/image/8ufthri38j1e0u/'; 
       $xr=$_FILES['imag']['name'];$xt=$_FILES['imag']['tmp_name']; 
                 $result="8ufthri38j1e0u/".$xr;
				
				
  if (move_uploaded_file($xt,$result)) { 
          $string="Ome15rt08j1ufh3u8ire";
	                 $string=substr($string,6);
	   
       $ciag=str_shuffle($string); $x=rename($result,"8ufthri38j1e0u/".SHA1($ciag).".jpg");
	           $wynik="8ufthri38j1e0u/".SHA1($ciag).".jpg"; 
	           
   } 
	
   else {
   echo " wystapił blad wysyłania pliku na serwer ";
	 
   }
					
   if ($x==true) 	{ 
   mysql_query("INSERT INTO `image_url`(`url`,`id`)VALUES('$wynik',$_SESSION[id])");
 
 	  
}

}

}

dodajFotki();

?>

</br>
</br>

    
<div class='upload'>
<form action="add_images.php"  enctype="multipart/form-data" method="post">
dodaj nowy plik: <input type="file" name="imag" id="uploadFile" placeholder="Choose File"/><p> 
<input type="submit" id="przycisk" name="przycisk" value="wyslij" />
</form>
<div style="font-size:11px;padding:3px 3px 3px 3px;">

 <p id='a'>
</p>
</div>
</div>


<?php
require_once "includes/footer.php"; 
} 

else {
header("location:index.php");

}

?>
 