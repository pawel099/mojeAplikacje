<?php 
session_start();
if (isset($_SESSION['uzytkownik'])) {
require_once 'function/funkcje.php'; 
 
 if ($p=$wynik->wpisy()) {
 header('Location:images.php'); 
 
}
 
require_once 'includes/header.php'; 	
?>

<div id="warrp_user" style="width:320px;margin-top:25px;margin-left:50px;font-family:verdana;font-size:12px;">

 
<?php 
 
if ($wynik->wpisy()==true) {
echo $wynik->errors ;
    
} 
   
else {
foreach ($wynik->news as $i) {
  
?>


</div>
 
<div style="margin-left:40px;margin-top:80px;margin-bottom:60px;">
<table width=600px; style="padding:12px 12px 12px 12px;">
  
<tr>
<td style="padding:10px 10px 10px 10px;"><form name="forms" action="" method="post"></td> 
</tr>	

<tr style="padding-top:30px;">

<td><input type="checkbox" name="<?php echo $i['user']?>"></td>
<td><a href="<?php echo $i['x'];?>"><img src="<?php echo $i['x'];?>" width="80" height="80"></a></td>
<td style="font-family:arial;font-size:11px;">    data dodania    <?php echo $i['data'];?></td> 
</tr>
 
<?php
 
} 
?>

 


<tr>

              <td width=12px; colspan=4 style="padding-left:380px;padding-top:98px"> 
               
              <form action="" method="post">
              <select name="lista" border=1px width=40px;>
              <option value="wybierz"> czynnosci masowe  </option>
              <option value="delete"> usuń  </option>
      
	          </select>

</td>
</tr>

     
<td  width=12px; colspan=4 style="padding-left:14px;padding-top:0px"> 
<input type="submit" onClick="sprCheck();" name="x" value="zatwierdz" style="border-style:0px;padding-left:8px;padding-right:8px;color:#7391cf">
</form>
</td>
</tr>

                    
 
</table>
</div> 

 
 
<?php

foreach ($wynik->news as $i) {
  
        if (isset($_POST[$i['user']]))  {
        $wynik->dane($i['userd'],$i['url']); 
   

      }
 
  }

}

require_once "includes/footer.php"; 

} 

else {
header("location:index.php");

}

?>
 





 