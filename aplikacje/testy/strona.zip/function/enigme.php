<?php 

  interface zaloguj {
      
    function log_user($user,$pass);
	 
  
  }  
  
  
class klasa {

var $host;
var $root;

var  $pass;
var  $db;


  function __construct($host,$user,$haslo,$db) {
	
	$this->host=$host;	
	$this->root=$user;	
	
	$this->pass=$haslo;
	$this->db=$db;
	
	
	 mysql_connect($this->host,$this->root,$this->pass)or die("wystapił blad polaczenia z serwerem");
                     mysql_select_db($this->db)or die("wystapił blad polaczenia z baza danych");
					 
      
	}

}

class validateForm implements zaloguj {


   function log_user($user,$pass) {
      
	 if (isset($_POST['Submits'])) {
	        if  (empty($user) || empty($pass) || !preg_match("/^[a-z]{1,15}[1-9]{1,8}$/",$pass) || strlen($user)>12) {
		             $this->er_user=" blad logowania ";
	         
			 	
			 
		}
						   
		
	   }   

}

} 

 class logins implements zaloguj {
 
       function log_user($user,$pass) {
	     
		   $x=mysql_real_escape_string(trim($user));
		               $y=mysql_real_escape_string($pass);
	    
	                          $query=mysql_query("SELECT *FROM `user_gallery` WHERE `user`='$x' and haslo='$y'");
			    
			
		if (mysql_num_rows($query)!==0) {
			 
			        $wynik=mysql_fetch_assoc($query);
				          
					$_SESSION['uzytkownik']=$wynik['user'];
					$_SESSION['id']=(int) $wynik['id'];
								
							 
							  
							 
                      
		  }    
	          
	}
}

    new klasa('localhost','root','woyadzerxt1756','images');
	
	$tablica=array($i=new validateForm,new logins); 	
       foreach ($tablica as $obiekt) {
		     $obiekt->log_user($_POST['user'],$_POST['pass']); 
			 
             
                
	 }		
 



 











