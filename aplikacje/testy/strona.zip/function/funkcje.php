<?php

 class wyswietlDane {
        
		
		private function polacz() {
                require 'enigme.php ' ;
 
 }

        function __construct() {
               $this->polacz();
	
  }
  
  public function images() {
			  
			  $this->dane=mysql_query("SELECT *FROM `image_url` 
		      INNER JOIN `user_gallery` ON image_url.id=user_gallery.id  
		      WHERE image_url.id='$_SESSION[id]' ORDER BY `url` ASC"
			  	  
				  
		    
);

while ($tab=mysql_fetch_assoc($this->dane)) {
$new[]=array("userd"=>$tab['user_id'],"user"=>$tab['user_id'],"id"=>$tab['id'],"url"=>$tab['url'],"dat"=>$tab['data']);
$this->news=$new;
 
}

if (mysql_num_rows($this->dane)==0) {
$this->errors=" add photos your gallery
<a href='add_images.php'> add your photos </a>";

return true;

}

 
}

   
function dane($id,$t) {

if (isset($_POST['lista']) && $_POST['lista']=="delete") {
$link=mysql_query("DELETE FROM `image_url` WHERE `user_id`='$id'") or die(mysql_error());
  
   if (!empty($t) && $link==true) {
   unlink($t); 
  
  }
  
return $link;

}

} 
 
         
}		  
		 
 
$wynik=new wyswietlDane ;

  
 
  
  
  
 
	
	
	
	
	
 











