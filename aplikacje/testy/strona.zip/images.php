<?php 
session_start();
if (isset($_SESSION['uzytkownik'])) {
require_once 'function/funkcje.php'; 
 
 if ($x=$wynik->dane($id,$t)) {
 header('Location:images.php'); 
 
}
 
require_once 'includes/header.php'; 	
?>


<div id="warrp_user" style="width:320px;margin-top:25px;margin-left:50px;font-family:verdana;font-size:12px;">
 
 
<?php 
 
if ($wynik->images()==true) {
echo $wynik->errors ;
    
} 
   
else {
foreach ($wynik->news as $i) {
 
?>


</div>
 
<div style="margin-left:40px;margin-top:80px;margin-bottom:60px;">
<style type="text/css">

td {
 text-align:center;
 padding:30px 30px 30px 30px;
 
 }
 
</style>
<table width=600px>
     
	 
	 <tr> 
	 
	 <td style="padding-left:152px;"><form action="" method="post"><input type="checkbox" name="<?php echo $i['user']?>"/>
	 </td><td><a href="praca.php?pid=<?php echo $i['user'];?>"><img src="<?php echo $i['url'];?>" width="80" height="80"></a></td>
	 <td style="font-family:verdana;font-size:10px"> data dodania <?php echo $i['dat'];?></td> </tr> 
	 
	 
</table>	 
 
<?php

}

 
 
 
?>

<table style="width:600px;margin-top:25px;">


<tr>
	   
	<td> <select name="lista" border=1px width=40px;> 
    <option value="wybierz"> czynnosci masowe  </option> 
    <option value="delete"> usuń  </option> </select> </td>
	 
<td colspan=2><input type="submit" name="x" value="zatwierdz"></form></td>
</tr>
</table>	 
  

</div> 

<?php

foreach ($wynik->news as $i) {
  
if (isset($_POST[$i['user']]))  {
$wynik->dane($i['userd'],$i['url']); 
   

}
 
}

}

require_once "includes/footer.php"; 

} 

else {
header("location:index.php");

}

?>
 





 