<?php 
session_start(); 
if (isset($_SESSION['uzytkownik'])) {
require_once 'function/funkcje.php'; 
 
 if ($x=$wynik->dane($id,$t)) {
 header('Location:images.php'); 
 
}
 
require_once 'includes/header.php'; 
require_once 'includes/big_image.php'; 
	
?>



 
<?php 

   
if ($wynik->images()==true) {
$wynik->errors;
    
} 
   
else {

foreach ($wynik->news as $d) {
 
?> 
 
<?php

}

}

 

require_once "includes/footer.php"; 

} 

else {
header("location:index.php");

}

?>