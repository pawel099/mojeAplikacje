<?php 
if (isset($_SESSION['uzytkownik'])) {
$wynik->images(); 

foreach ($wynik->news as $id) {

$_GET['pid']  = (int)  $_GET['pid']; 

if ($id[userd]==$_GET['pid']) {
$image = $id[url];

 

 
 

?>

<div class ="lista">

<ul type="square"> 
<li> <b>imie</b> - pawel </li>
<li> <b>nazwisko</b> - stawicki </li>
<li><b>wiek</b> - 35 lat </li>
</ul>

<hr class="linia">

<ul type="circle"> 
<li><a href='list.php'>dodaj do znajomych</a></li>
<li><a href='list.php'>czarna lista</a></li>
<li><a href='list.php'>moje kontakty..</a></li>
</ul> 

</div>

 
<div class="images">
<img src="<?php echo $image;?>" width="480px",height="330px"> 
 
</div> 

<?php

} 

}

}

 

 



else {
header("Location:.");
}

?>
 

 
 