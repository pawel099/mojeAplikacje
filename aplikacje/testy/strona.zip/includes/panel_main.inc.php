<?php 

if (isset($_SESSION['uzytkownik'])) {
require_once "includes\header.php";

require_once "footer.php";
} 

else {
header("location:..\index.php");

}

?>
