<!DOCTYPE>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/views.css"/>
<link rel="stylesheet" type="text/css" href="css/api.css"/>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>my web slide gallery</title> 
<body>
<div id='contents'>
<div id='header'>

<div class='kokpit_userx'>
 
</div>

<?php 
if (!isset($_SESSION['uzytkownik'])) {
?>
<div class='kokpit_user'> 
<table style="border-style:solid 1px;">
<tr>

<form action="index.php" method="post">
<td>&nbspuzytkownik&nbsp&nbsp<input type='text' name="user"/></td> 
<td>&nbsp haslo &nbsp&nbsp&nbsp<input type="password" name="pass"/></td>
<td style='padding-left:16px;'><input type='submit' name="Submits" style="height:19px;border-radius:2px;border:1px;font-family:arial;color:navy; 
padding-bottom:7px; " value='log-in'></div>
</form></td>
</tr>
</table>
</div>

 
<?php 
}
else {
$_SESSION['uzytkownik'];
?>

<div class="user">
<span><b>witaj!</b></span>   
<span><b><?php echo $_SESSION['uzytkownik'];?><a href="logout">wyloguj sie</a></b></span>
</div>

</div>

<div class="panel">
 <div class="links" style="margin-left:11px;">

<a class='d' href="add_images.php">dodaj fotki</a></span>
<a class='d' href="images.php">media</a></span>
<a class='d' href="posts.php">wpisy</a></span>

</div>
</div>

 
 
<?php 

}  

