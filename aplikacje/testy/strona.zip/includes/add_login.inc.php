<?php 
if (!isset($_SESSION['uzytkownik'])) {
?>

</div>
  <p>
  <table style='font-family:verdana;font-size:11px;color:#bac8e5;padding:5px 5px 5px 5px;' width=400> 
          <form action="index.php" method="post">
			<tr>  <td>twoj login</td>
			              <td><input type="text" size='30px' name="user"/></td>
	</tr> 
	    <tr> <td>twoje haslo</td>
			          <td><input type="password" size='30px' name="pass"/></td> 
			</tr>
			
		 <tr>  <td><input type="Submit" style='border-style:0px;padding-left:8px;padding-right:8px;color:#7391cf' name="Submits" value="zaloguj"/></td> </form>
			  </tr>
			
 
</table>
<div>
<?php echo $i->er_user;?>
</div>


<?php

}