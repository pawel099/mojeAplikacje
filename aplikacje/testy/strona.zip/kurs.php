<?php
 
 class komentarze {
 
 public function dane($nick,$tresc) {
	  
	 
	  $this->y=$nick;
	  $this->x=$tresc;
	  
	  
	  if (empty($this->y) || empty($this->x) ) {
	     $this->error=" wystapił blad dodania komentarza ";
	       return false;
	  }

	 else {
	    
		$file="dane.txt";
		$wynik=date("H:i:s")." ".$nick." napisał :  ". " ".$tresc."<p>";
	    file_put_contents($file,$wynik,FILE_APPEND); 
		  
	  }
	  
	  
	  
}


}

$r=new komentarze;
if (isset($_POST['a'])) {
$r->dane($_POST['nick'],$_POST['tresc']);


}


?>
<!DOCTYPE>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>

<title> system komentarzy</title>
</head>
<body>

 

 
<form  action="kurs" method="post"></td>
 

<?php echo $r->error;?><p>
 
podaj swoj nick &nbsp&nbsp&nbsp <input style="width:200px;" type="text" name="nick"> <p> 
 <textarea name="tresc" cols="47" rows="8" class="typ">
</textarea><p>
 <input type="submit"  name="a" value="wyslij">
</form> 
 


<div style="margin-top:20px;padding:15px 15px 15px 15px;">
 
 <?php echo file_get_contents('dane.txt');?>      
</div>
</body>
</html>






