
 <table class="typ">

<tr>
<td><form name="the_form" action="rejestracja.php" method="post"></td>
</tr>


<tr>
<td id='outing'>podaj login</td> 
<td><input class="typ" type="text" name="login"></td> 
<td>(max 25 znaków)</td>
</tr> 

<tr>
 
<td>podaj mail</td>
<td><input class="typ" type="text" name="mail"></td>
</tr>


<tr>
 
<td>podaj haslo</td>
<td><input class="typ" type="password" name="password"></td>
</tr>


<tr>
 
<td>powtórz haslo</td>
<td><input class="typ" type="password" name="rpassword"></td>
</tr>

<tr>
<td><input type="submit" name="klik" OnClick="addLoadChecker();return false"; value="wyslij">
</form></td>
</tr>

</table>

<style type="text/css">

 td.err {
 font-family:arial;
 color:red; 
} 

 td {
 padding-bottom:30px;
 padding-left:5px;
 font-family:arial;
 font-size:10px; 
  
 }

 input.typ  {
 width:180px;
  
 }
 
</style>

<script type="text/javascript">

  function addLoadChecker() {
   
       
	   var zmienna=document.getElementById("outing");
	   
	   if (zmienna.setAttribute('id','outing')==null) {
	   return false;
	   
	   }    else {
		 
	   if (window.document.the_form.login.value=="") {
	   
	      var x=document.createTextNode("I'm your new div.");
	   
	   zmienna.appendChild(x);
	   
}
	   
}
	   
}
	  
	  
</script>


<?php 
?>   
   
 
 