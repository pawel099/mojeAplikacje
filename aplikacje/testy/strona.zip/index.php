<?php 
session_start();
 
if (isset($_SESSION['HTTP_USER_AGENT']))
{
    if ($_SESSION['HTTP_USER_AGENT']!=md5($_SERVER['HTTP_USER_AGENT']))
    {
        /* Poproszenie o hasło */
        exit;
    }
}
else
{
    $_SESSION['HTTP_USER_AGENT']=md5($_SERVER['HTTP_USER_AGENT']);
}

include_once 'function/enigme.php';  
include_once 'includes/header.php';

	  
 
        if (isset($_SESSION['uzytkownik'])) {
               include_once 'includes\panel_main.inc.php ';
 } 
 
 
    else {
	  
	          
			 
			 include_once 'includes/footer.php';
   }
   
   
   
 
?>
 
 
  

