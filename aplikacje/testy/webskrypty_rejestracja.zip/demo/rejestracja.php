<?php
ob_start();
session_start(); // rozpoczęcie sesji
?>

<?php include('header.php'); ?>

<h2>&raquo; Zarejestruj się</h2>
<div class="content">
<?php

if (!isset($_SESSION['login'])) { // dostęp dla zalogowanego użytkownika

    include 'inc/db.php'; // połączenie się z bazą danych
    $tabela = 'rejestracja'; // zdefiniowanie tabeli MySQL
    include 'inc/recaptchalib.php'; // dołączenie modułu reCAPTCHA
    $privatekey = "WPISZ TUTAJ KLUCZ PRYWATNY"; // prywatny klucz reCAPTCHA
    $publickey = "WPISZ TUTAJ KLUCZ PUBLICZNY"; // publiczny klucz reCAPTCHA

if ($_POST["wyslane"]) { // jeżeli formularz został wysłany, to wykonuje się poniższy skrypt

        // filtrowanie treści wprowadzonych przez użytkownika
        $login = htmlspecialchars(stripslashes(strip_tags(trim($_POST["login"]))), ENT_QUOTES);
        $haslo = $_POST["haslo"];
        $haslo2 = $_POST["haslo2"];
        $email = htmlspecialchars(stripslashes(strip_tags(trim($_POST["email"]))), ENT_QUOTES);
        $email2 = htmlspecialchars(stripslashes(strip_tags(trim($_POST["email2"]))), ENT_QUOTES);
        $imie = htmlspecialchars(addslashes(strip_tags(trim($_POST["imie"]))), ENT_QUOTES);
        $nazwisko = htmlspecialchars(addslashes(strip_tags(trim($_POST["nazwisko"]))), ENT_QUOTES);
        $resp = recaptcha_check_answer ($privatekey,
                $_SERVER["REMOTE_ADDR"],
                $_POST["recaptcha_challenge_field"],
                $_POST["recaptcha_response_field"]);

        // system sprawdza czy prawidło zostały wprowadzone dane
        if (strlen($login) < 3 or strlen($login) > 30 or !eregi("^[a-zA-Z0-9_.]+$", $login)) {
            $blad++;
            echo '<span class="blad">Proszę poprawny wprowadzić login (od 3 do 30 znaków).</span>';
        } else {
            $wynik = mysql_query("SELECT * FROM $tabela WHERE login='$login'");
            if (mysql_num_rows($wynik) <> 0) {
                $blad++;
                echo '<span class="blad">Podana nazwa użytkownika została już zajęta.</span>';
            }
        }
        if (strlen($haslo) < 6 or strlen($haslo) > 30 ) {
            $blad++;
            echo '<span class="blad">Proszę poprawnie wpisać hasło (od 6 znaków do 30 znaków).</span>';
        }
        if ($haslo !== $haslo2) {
            $blad++;
            echo '<span class="blad">Podane hasła nie są ze sobą zgodne.</span>';
        }
        if (!eregi("^[0-9a-z_.-]+@([0-9a-z-]+\.)+[a-z]{2,4}$", $email)) {
            $blad++;
            echo '<span class="blad">Proszę wprowadzić poprawnie adres email.</span>';
        } else {
            $wynik = mysql_query("SELECT * FROM $tabela WHERE email='$email'");
            if (mysql_num_rows($wynik) <> 0) {
                $blad++;
                echo '<span class="blad">Podany adres e-mail jest już zajęty.</span>';
            }
        }
        if ($email !== $email2) {
            $blad++;
            echo '<span class="blad">Podane adresy e-mail nie są ze sobą zgodne.</span>';
        }
        if (!$resp->is_valid) {
            $error = $resp->error;
            echo '<span class="blad">Proszę wpisać poprawnie wyrazy z obrazka.</span>';
            $blad++;
        }

        // jeżeli nie ma żadnego błedu, użytkownik zostaje zarejestronwany i wysłany do niego e-mail z linkiem aktywacyjnym
        if ($blad == 0) {

            $haslo = md5($haslo); // zaszyfrowanie hasla
            $kod = uniqid(rand()); // tworzenie unikalnego kodu dla użytkownika

            $wynik = mysql_query("INSERT INTO $tabela VALUES('', '$imie', '$nazwisko', '$login', '$haslo', '$email', '$kod', NOW(), '')");
            if ($wynik) {
                $list = "Witaj $login !
                Kliknij w poniższy link, aby aktywować swoje konto. http://www.nazwa-twojej-strony.pl/weryfikacja.php?weryfikacja=potwierdz&kod=$kod";
                mail($email, "Rejestracja użytkownika", $list, "From: <kontakt@twoja-strona.pl>");
                echo '<p>Dziękujemy za rejestrację! W ciągu nabliższych 5 minut dostaniesz wiadomość e-mail z dalszymi wskazówkami rejestracji.</p>';
                mysql_close($polaczenie);
                exit;
            }
        }
        mysql_close($polaczenie);
    }

    // tworzenie formularza HTML
    echo <<< KONIEC
	
    <div class="formularz">
    <form class="form" action="rejestracja.php" method="post">
    <input type="hidden" name="wyslane" value="TRUE" />

			<p>
				Pola oznaczone gwiazdką <span class="req">*</span> to pola wymagane.
			</p>
	
			<p>
				<div class="label"><label for="imie">Imię</label></div>
				<input type="text" name="imie" id="imie" />
			</p>

			<p>
				<div class="label"><label for="nazwisko">Nazwisko</label></div>
				<input type="text" name="nazwisko" id="nazwisko" />
			</p>

			<p>
				<div class="label"><label for="login">Login <span class="req">*</span></label></div>
				<input type="text" name="login" id="login" />
			</p>
	
			<p>
				<div class="label"><label for="haslo">Hasło <span class="req">*</span></label></div>
				<input type="password" name="haslo" id="haslo" />
			</p>
	
			<p>
				<div class="label"><label for="haslo2">Powtórz hasło <span class="req">*</span></label></div>
				<input type="password" name="haslo2" id="haslo2" />
			</p>
	
			<p>
				<div class="label"><label for="email">Email <span class="req">*</span></label></div>
				<input type="text" name="email" id="email" />
			</p>
	
			<p>
				<div class="label"><label for="email2">Powtórz email <span class="req">*</span></label></div>
				<input type="text" name="email2" id="email2" />
			</p>
KONIEC;
   echo '<div class="recaptcha">';
   echo recaptcha_get_html($publickey); // wyświetlanie reCAPTCHA
   echo '</div>';
   echo <<< KONIEC
   <p class="submit">
      <input type="submit" value="Zarejestruj mnie" />
   </p></form>
KONIEC;

} else {
    header('Location: /index.php');
}
?>

</div>
<?php include('footer.php'); ?>