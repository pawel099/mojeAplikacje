<div id="footer">
	<p>Ostatnia aktualizacja skryptu: <strong>21 marca 2010</strong>.<br /><br /> 
	<strong>Autor skryptu</strong>: <a href="http://www.webskrypty.pl" title="WEBskrypty.pl - Ajax, PHP, MySQL, Wordpress">www.webskrypty.pl</a>.<br /><br>
	&raquo; <a href="http://www.webskrypty.pl/2010/system-rejestracji-uzytkownikow/">Przejdź do artykułu</a>.
	</p>
</div>
</div>
</body>
</html>