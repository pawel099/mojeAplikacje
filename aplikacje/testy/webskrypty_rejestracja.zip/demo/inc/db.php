<?php

// dane do połączenia z bazą MySQL
$mysql_host = '';
$mysql_login = '';
$mysql_haslo = '';
$mysql_baza = '';

// połączenie z bazą danych
$polaczenie = mysql_connect($mysql_host, $mysql_login, $mysql_haslo) or die('Błąd: nie udało się nawiązać połączenia z bazą danych.');

// połączenie ze schematem bazy danych
mysql_select_db($mysql_baza) or die('Błąd: nie udało się wybrać schematu bazy danych.');

?>