<?php
ob_start();
session_start(); // rozpoczęcie sesji
?>

<?php include('header.php'); ?>

<h2>&raquo; Zaloguj się</h2>
<div class="content">

<?php

if (!isset($_SESSION['login'])) { // dostęp dla niezalogowanego użytkownika

    if ($_POST['wyslane']) { // jeżeli formularz został wysłany, to wykonuje się poniższy skrypt

        include 'inc/db.php'; // połączenie się z bazą danych
        $tabela = 'rejestracja'; // zdefiniowanie tabeli MySQL 

        $login = $_POST["login"];
        $haslo = $_POST["haslo"];

        $haslo = md5($haslo); // szyfrowanie podanego hasła

        $wynik=mysql_query("SELECT * FROM $tabela WHERE
        login='$login' and haslo='$haslo' and status=0");

        // jeżeli użytkownik zarejestrował się, a nie aktywował swojego konta, to wyświetla się komunikat
        if (mysql_num_rows($wynik) == 1) {
            $informacja = mysql_fetch_array($wynik);
            echo '<span class="blad">Nie aktywowałeś jeszcze swojego konta. Aby to zrobić, wejdź w swoją skrzynkę odbiorczą, a następnie znajdź wiadmość z linkiem aktywacyjnym i aktywuj swoje konto</span>';
            exit;
        }

        // jeżeli wszystko jest dobrze, użytkownik się loguje
        $wynik=mysql_query("SELECT * FROM $tabela WHERE
        login='$login' and haslo='$haslo' and status=1");

        if (mysql_num_rows($wynik) == 1) {
            $informacja = mysql_fetch_array($wynik);
            $_SESSION["login"] = $informacja["login"];
            header('Location: index.php ');
        } else {
            echo '<span class="blad">Zostały wprowadzone nieprawidłowe dane!</span>';
        }
        mysql_close($polaczenie);
    }

    // tworzenie formularza HTML  
    echo <<< KONIEC
	
    <form class="form" action="logowanie.php" method="post">
    <input type="hidden" name="wyslane" value="TRUE" />

    <p>
	  <div class="label"><label for="login">Login</label></div>
	  <input type="text" name="login" id="login" />
	</p>
	
	<p>
	  <div class="label"><label for="haslo">Hasło</label></div>
	  <input type="password" name="haslo" id="haslo" />
	</p>

    <p class="submit2">
      <input type="submit" value="Zaloguj mnie" />
    </p>
	
	<p class="przypomnij">
		<a href="przypomnienie.php">Nie pamiętasz hasła?</a>
	</p>

    </form>
KONIEC;

} else {
    header('Location: index.php'); // zalogowany użytkownik zostaje przekierowany na stronę główną
}

if ($_GET["wylogowanie"] == "tak") {
    // niszczenie sesji użytkownika
    session_unset();
    session_destroy();
    header('Location: index.php'); // przekierwanie na stronę główną
}

?>

</div>
<?php include('footer.php'); ?>