<?php
ob_start();
session_start(); // rozpoczęcie sesji
?>

<?php include('header.php'); ?>

<h2>&raquo; Zmiana danych</h2>
<div class="content">

<?php

include 'inc/db.php'; // połączenie się z bazą danych
$tabela = 'rejestracja'; // zdefiniowanie tabeli MySQL

if (isset($_SESSION['login'])) { // dostęp dla zalogowanego użytkownika

    if ($_POST['wyslane']) { // jeżeli formularz został wysłany, to wykonuje się poniższy skrypt

        // filtrowanie treści wprowadzonych przez użytkownika
        $email = htmlspecialchars(stripslashes(strip_tags(trim($_POST["email"]))), ENT_QUOTES);
        $haslo = $_POST["haslo"];
        $haslo2 = $_POST["haslo2"];

        // system sprawdza czy prawidłowo zostały wprowadzone dane
        if (!eregi("^[0-9a-z_.-]+@([0-9a-z-]+\.)+[a-z]{2,4}$", $email)) {
            $blad++;
            echo '<span class="blad">Proszę wprowadzić poprawnie adres email.</span>';
        }
		$wynik = mysql_query("SELECT * FROM $tabela WHERE login='{$_SESSION["login"]}'");
		if ($wynik) {
			$informacja = mysql_fetch_array($wynik);
     
			if ($email !== $informacja['email']) {
				$wynik = mysql_query("SELECT * FROM $tabela WHERE email='$email'");
				if (mysql_num_rows($wynik) <> 0) {
					$blad++;
					echo '<span class="blad">Podany adres e-mail jest już zajęty.</span>';
				}
			}	 
		}
        if ($haslo) {
            if (strlen($haslo) < 6 or strlen($haslo) > 30) {
                $blad++;
                echo '<span class="blad">Proszę poprawnie wpisać hasło (od 6 znaków do 30 znaków).</span>';
            }
        }
        if ($haslo !== $haslo2) {
            $blad++;
            echo '<span class="blad">Podane hasła nie są ze sobą zgodne.</span>';
        }

        // jeżeli błąd nie wystąpił, to dane zostają prawidłowo zapisane z bazie MySQL
        if ($blad == 0) {

            if ($haslo == false) {
                $wynik = mysql_query("UPDATE $tabela
            SET email='$email' WHERE login='{$_SESSION['login']}'");
            } else {
                $haslo = md5($haslo); // szyfrowanie hasla
                $wynik = mysql_query("UPDATE $tabela
            SET haslo='$haslo', email='$email' WHERE login='{$_SESSION['login']}'");
            }

            if ($wynik) {
                echo '<span class="powodzenie">Dane zostały zmienione.</span>';
            } else {
                echo '<span class="blad">Dane nie zostały zmienione.</span>';
            }
        }
    }

    $wynik = mysql_query("SELECT * FROM $tabela WHERE
          login='{$_SESSION["login"]}'");
    if ($wynik) {
        $informacja = mysql_fetch_array($wynik);

        // tworzenie formularza HTML z danymi użytkownika
        echo <<< KONIEC

    <form class="form" action="zmiana-danych.php" method="post">
    <input type="hidden" name="wyslane" value="TRUE" />
	
	<p>
	  <div class="label"><label for="login">Login</label></div>
	  <input type="text" name="login" id="login" disabled="disabled" value="{$informacja['login']}" />
	</p>
	
	<p>
		<div class="label"><label for="email">Email</label></div>
		<input type="text" name="email" id="email" value="{$informacja['email']}" />
	</p>
	
    <p>
		<div class="label"><label for="haslo">Hasło</label></div>
		<input type="password" name="haslo" id="haslo" />
	</p>
	
	<p>
		<div class="label"><label for="haslo2">Powtórz hasło</label></div>
		<input type="password" name="haslo2" id="haslo2" />
	</p>

    <p class="submit2">
		<input type="submit" value="Aktualizuj moje dane" />
	</p>

KONIEC;
    }
    mysql_close($polaczenie);

} else {
    header('Location: index.php'); // niezalogowany użytkownik zostaje przekierowany na stronę główną
}

?>

</div>
<?php include('footer.php'); ?>
