<?php
ob_start();
session_start(); // rozpoczęcie sesji
?>

<?php include('header.php'); ?>

<h2>&raquo; Zaloguj się</h2>
<div class="content">

<?php

if (!isset($_SESSION['login'])) { // dostęp dla niezalogowanego użytkownika

    include 'inc/db.php'; // połączenie się z bazą danych
    $tabela = 'rejestracja'; // zdefiniowanie tabeli MySQL

    if ($_POST['wyslane']) { // jeżeli formularz został wysłany, to wykonuje się poniższy skrypt

        $login = htmlspecialchars(stripslashes(strip_tags(trim($_POST["login"]))), ENT_QUOTES); // filtrowanie $_POST['login']

        $hasloodszyfrowane = uniqid(rand()); // tworzenie nowe hasła
        $haslo = md5($hasloodszyfrowane); // szyfrowanie hasła

        // użytkownikowi zostaje zmienione hasło, które system wygenerował
        // jeżeli podanego loginu nie ma w bazie, wyświetla się komunikat
        $wynik = mysql_query("UPDATE $tabela
        SET haslo='$haslo' WHERE login='$login' and status=1");

        $wynik = mysql_query("SELECT * FROM $tabela
           WHERE login='$login' and status=1");

        if (mysql_num_rows($wynik) == 1) {
            $informacja = mysql_fetch_array($wynik);
            $email = $informacja["email"];
            $list="Twoje nowe wygenerowane hasło to: $hasloodszyfrowane";
            mail($email, "Przypomnienie hasla", $list, "From: <kontakt@twoja-strona.pl>");
            echo '<span class="powodzenie">Nowe hasło zostało wysłane na adres e-mail wykorzystany podczas rejestracji konta.</span>';
        } else {
            echo '<span class="blad">Użytkownik o podanym loginie nie istnieje!</span>';
        }
        mysql_close($polaczenie);
    }

    // tworzenie formularza HTML
    echo <<< KONIEC

    <form class="form" action="przypomnienie.php" method="post">
    <input type="hidden" name="wyslane" value="TRUE" />

    <p>
	  <div class="label"><label for="login">Podaj swój login</label></div>
	  <input type="text" name="login" id="login" />
	</p>

    <p class="zaloguj"><input type="submit" value="Wyslij mi nowe hasło" /></p>

KONIEC;

} else {
    header('Location: /index.php'); // zalogowany użytkownik zostaje przekierowany na stronę główną
}

?>

</div>
<?php include('footer.php'); ?>