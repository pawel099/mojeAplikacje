<?php
ob_start();
session_start(); // rozpoczęcie sesji
?>

<?php include('header.php'); ?>

<h2>&raquo; System rejestracji użytkowników<br />PHP & MySQL</h2>
<div class="content">

<?php
// jeżeli użytkownik jest zalogowany wyświetlamy inforamcję
if (isset($_SESSION['login'])) {  
	echo '<p><img class="user" src="img/user.png">Jesteś zalogowany jako: <strong>'.$_SESSION['login'].'</strong></p>';
}

else {
	echo '';
}
?>
<h3>Nasz system posiada:</h3>
<p>
<img class="tick" src="img/tick.png" alt="" /> Rejestrację (wraz z wbudowaną walidacją <strong>reCAPTCHA</strong>),<br />
<img class="tick" src="img/tick.png" alt="" /> Logowanie,<br />
<img class="tick" src="img/tick.png" alt="" /> Przypominanie hasła,<br />
<img class="tick" src="img/tick.png" alt="" /> Weryfikację konta poprzez e-mail,<br />
<img class="tick" src="img/tick.png" alt="" /> Zmianę danych użytkownika.<br />
</p> 

</div>

<?php include('footer.php'); ?>
