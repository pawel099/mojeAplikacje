<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>System rejestracji użytkowników PHP & MySQL | www.WEBskrypty.pl</title>
<link rel="stylesheet" href="css/style.css" type="text/css"
media="screen" />
</head>
<body>

<div id="menu">
   <ul>
      <li><a href="index.php">Strona główna</a></li>
      <?php if (isset($_SESSION['login'])) { echo ''; } else {?> 
	  <li><a href="logowanie.php">Logowanie</a></li>
	  <?php } ?>
      <?php if (isset($_SESSION['login'])) { echo ''; } else {?> 
	  <li><a href="rejestracja.php">Zarejestruj się</a></li>
	  <?php } ?>
	  <?php if (!isset($_SESSION['login'])) { echo ''; } else {?> 
	  <li><a href="zmiana-danych.php">Zmień swoje dane</a></li>
	  <?php } ?>
	  <?php if (!isset($_SESSION['login'])) { echo ''; } else {?> 
	  <li><a href="logowanie.php?wylogowanie=tak">Wyloguj się</a></li>
	  <?php } ?>
   </ul>
</div>