<?php

session_start();

include 'db.php'; // połączenie się z bazą danych
$tabela = 'uzytkownik'; // zdefiniowanie tabeli MySQL

if (isset($_SESSION['login'])) { // dostęp dla zalogowanego użytkownika

    if ($_POST['wyslane']) { // jeżeli formularz został wysłany, to wykonuje się poniższy skrypt

        // filtrowanie treści wprowadzonych przez użytkownika
        $email = htmlspecialchars(stripslashes(strip_tags(trim($_POST["email"]))), ENT_QUOTES);
        $haslo = $_POST["haslo"];
        $haslo2 = $_POST["haslo2"];

        // system sprawdza czy prawidłowo zostały wprowadzone dane
        if (!eregi("^[0-9a-z_.-]+@([0-9a-z-]+\.)+[a-z]{2,4}$", $email)) {
            $blad++;
            echo '<p>Proszę wprowadzić poprawnie adres email </p>';
        } 
		$wynik = mysql_query("SELECT * FROM $tabela WHERE login='{$_SESSION["login"]}'");
        if ($wynik) {
			$informacja = mysql_fetch_array($wynik);
     
			if ($email !== $informacja['email']) {
				$wynik = mysql_query("SELECT * FROM $tabela WHERE email='$email'");
				if (mysql_num_rows($wynik) <> 0) {
					$blad++;
					echo '<p> Podany adres e-mail jest już zajęty.</p>';
				}
			}	 
		}
        if ($haslo) {
            if (strlen($haslo) < 6 or strlen($haslo) > 30) {
                $blad++;
                echo '<p>Proszę poprawnie wpisać hasło (od 6 znaków do 30 znaków) <p/>';
            }
        }
        if ($haslo !== $haslo2) {
            $blad++;
            echo '<p>Podane hasła nie są ze sobą zgodne <p/>';
        }

        // jeżeli błąd nie wystąpił, to dane zostają prawidłowo zapisane z bazie MySQL
        if ($blad == 0) {

            if ($haslo == false) {
                $wynik = mysql_query("UPDATE $tabela
            SET email='$email' WHERE login='{$_SESSION['login']}'");
            } else {
                $haslo = md5($haslo); // szyfrowanie hasla
                $wynik = mysql_query("UPDATE $tabela
            SET haslo='$haslo', email='$email' WHERE login='{$_SESSION['login']}'");
            }

            if ($wynik) {
                echo '<p>Dane zostały zmienione</p>';
            } else {
                echo '<p>Dane nie zostały zmienione</p>';
            }
        }
    }

    $wynik = mysql_query("SELECT * FROM $tabela WHERE
          login='{$_SESSION["login"]}'");
    if ($wynik) {
        $informacja = mysql_fetch_array($wynik);

        // tworzenie formularza HTML z danymi użytkownika
        echo <<< KONIEC

        <form action="zmiana-danych.php" method="post">
        <input type="hidden" name="wyslane" value="TRUE" />

        <p>Login: <input type="text" name="login" disabled="disabled" value="{$informacja['login']}" /></p>
        <p>Adres e-mail: <input type="text" name="email" value="{$informacja['email']}" /></p>
        <p>Hasło: <input type="password" name="haslo" /></p>
        <p>Powtórz hasło: <input type="password" name="haslo2" /></p>

        <p><input type="submit" value="wyślij" /></p>
KONIEC;
    }
    mysql_close($polaczenie);

} else {
    header('Location: / '); // niezalogowany użytkownik zostaje przekierowany na stronę główną
}

?>
