CREATE TABLE `uzytkownik` (
      `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
      `imie` VARCHAR(100) NOT NULL,
      `nazwisko` VARCHAR(100) NOT NULL,
      `login` VARCHAR(30) NOT NULL,
      `haslo` VARCHAR(50) NOT NULL,
      `email` VARCHAR(100) NOT NULL,
      `kod` VARCHAR(32) NOT NULL,
      `data` DATETIME NOT NULL,
      `status` TINYINT(1) DEFAULT 0,

      PRIMARY KEY (`id`)
)
ENGINE=MyISAM DEFAULT CHARACTER SET latin1
    COLLATE latin1_general_cs AUTO_INCREMENT=0;