<?php

if ($_GET['weryfikacja'] == 'potwierdz') {

    include 'db.php'; // połączenie się z bazą danych
    $tabela = 'uzytkownik'; // zdefiniowanie tabeli MySQL

    $kod = htmlspecialchars(stripslashes(strip_tags(trim($_GET['kod']))), ENT_QUOTES); // filtrowanie $_GET['kod']

    // jeżeli kod znajduje się URL, skrypt najpierw patrzy czy użytkownik ma aktywne konto
    // jeżeli nie ma, wtedy zmienia się jego status, jeżeli nie upłynęło 48 godzin od rejestracji

    $wynik = mysql_query("SELECT * FROM $tabela
          WHERE kod='$kod' and status=1");

    if (mysql_num_rows($wynik) == 1) {
        echo '<p>Aktywowałeś już swoje konto.</p';
        exit; 
    } else {
        $wynik = mysql_query("DELETE FROM $tabela
          WHERE data<=DATE_SUB(NOW(),INTERVAL 2 DAY) and status=0");
        $wynik = mysql_query("UPDATE $tabela
          SET status='1', data=NOW() WHERE kod='$kod' and status=0");
        $wynik = mysql_query("SELECT * FROM $tabela
          WHERE kod='$kod' and status=1");
        if (mysql_num_rows($wynik) == 1) {
            echo '<p>Dziękujemy. Rejestracja została zakończona poprawnie. Możesz się teraz zalogować.</p>';
        }
    }

    // jeżeli został wprowadzony zły link, wyświetla się błąd
    if (!$kod or mysql_num_rows($wynik)<>1) {
        echo '<p>Aktywowanie konta nie powiodło się.</p>';
    }
    mysql_close($polaczenie);
}

?>