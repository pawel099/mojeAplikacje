<?php
session_start();

echo " <p style='font-family:verdana;font-size:10px;'>zamówiłes ".count($_SESSION['produkty'])." produktów "."<p>" ;

for ($i=0; $i<count($_SESSION['produkty']); $i++ ) {
    foreach ($tabelka as $dane) {
	
if ($_SESSION['produkty'][$i]==$dane['id']) {
	    
   echo "<hr>".$dane['product']."<br>"; 
   $results+=$dane['cena'];
	
  	
		 
}   


}

}

echo $tabelka['cena'];

if ($results==true) {
echo " <p style='font-family:arial;font-size:12px;font-weight:bolder;color:red;'>łaczna suma do zapłaty to "." ".  $results ." zł ";

} 

else {
echo " <p style='font-family:arial;font-size:12px;font-weight:bolder;color:red;'>łaczna suma do zapłaty to "." ".'0'. " zł ";

}
  
 

 
 
 
 