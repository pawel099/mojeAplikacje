<?php
session_start();

 $tabelka=array( 
 
   array('id'=>1,'product'=>'balon.jpg','cena'=>123),
   array('id'=>2,'product'=>'piłka.jpg','cena'=>100),
   array('id'=>3,'product'=>'spadochron.jpg','cena'=>11),
   array('id'=>4,'product'=>'bikini.jpg','cena'=>19) 
 
  );
 
 
function add_product() {

if (isset($_POST['a'])) {
$_SESSION['produkty'][]=$_POST['pole'];


} 

}
  
add_product();

  function oblicz($suma) {
  echo $suma;
  
  }
 
?>