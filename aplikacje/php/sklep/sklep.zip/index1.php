<?php 
session_start();
require 'shopping_func.php';
?>
<!DOCTYPE>
<html>
<head>
<meta http-equiv='content-type' content='text/html;charset=UTF-8'/>
<title> Koszyk na zakupy-php </title>
<body> 
 
<table  style='margin-left:140px;margin-top:0px;font-family:verdana;size:9px;color:#0000a2; 
padding:15px 15px 15px 15px;'>

<?php 
if (isset($_GET['card'])) {
include_once "sprawdz_koszyk.php ";
 exit();
}
?>

<tr>
<td style='padding-right:170px;font-family:sans;font-size:12px;'>twoj koszyk zawiera <a style='text-decoration:none'; href='?card'>
<?php echo count($_SESSION['produkty']);
 
?> 
</a>produktów</td></tr>
</tr>


<tr>



<?php
foreach ($tabelka as $id) { 
 
?>

<form action='' method='post'>


<tr>
<input type='hidden' name="pole" value="<?php echo $id[id];?> ">
<td style='padding-top:100px;padding-left:15px;font-family:verdana;font-size:12px;border-bottom:dotted 1px;'> <?php echo $id[product];?> <p>
<td style='padding-top:100px;padding-left:15px;font-family:verdana;font-size:12px;'><?php echo "cena" ." ". $id[cena];?> </td>
</td> 

<td style='padding-top:100px;padding-left:15px;font-family:verdana;font-size:12px;'><input type='submit' name='a' value='kup'>
</form> 
</td>


</tr> 
 
<?php


}
 
?>
  
 </tr> 
  
</table> 
</body>
</html>
